VEINCAM v1.1 

Scripts authored by Alex Ollman based on code from Miguel Grinberg (October 2014)
https://blog.miguelgrinberg.com/post/video-streaming-with-flask

Script 'app.py' is primary script handling Flask server and image stream, and will run on startup.
Must be run in OpenCV environment (bash: workon cv with cv2 package installed)

Image capture and processing performed by camera_opencv.py. This script can be edited using OpenCV image
processing techniques to get the clearest vein image possible. Histogram equalisation has been performed
as only processing technique as it fulfills requirements for project of clear vein imagery. 

pijuice.py written by PiJuice and is used to read status of PiJuice battery. If not using a PiJuice, 
delete "import pijuice" line and all affliated code relating to the pijuice in app.route('/') section
in the 'app.py' script.

Web page HTML found in 'templates' folder.
