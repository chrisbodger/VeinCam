#VEINCAM Camera Image Script
#Authored by Alex Ollman for ENGN4221 Engineering Project
#Based on open source code from Miguel Grinberg (October 2014).
#https://blog.miguelgrinberg.com/post/video-streaming-with-flask
#Last Edited 8/10/2018

import cv2
from picamera.array import PiRGBArray
import picamera
from base_camera import BaseCamera
import numpy as np
import time
import temp


class Camera(BaseCamera):
    video_source = 0
    
    def rotate_bound(image, angle):
        #https://www.pyimagesearch.com/2017/01/02/rotate-images-correctly-with-opencv-and-python/
        #Written by Adrian Rosebrock, January 2017
        
        # grab the dimensions of the image and then determine the
        # center
        (h, w) = image.shape[:2]
        (cX, cY) = (w // 2, h // 2)
 
        # grab the rotation matrix (applying the negative of the
        # angle to rotate clockwise), then grab the sine and cosine
        # (i.e., the rotation components of the matrix)
        M = cv2.getRotationMatrix2D((cX, cY), -angle, 1.0)
        cos = np.abs(M[0, 0])
        sin = np.abs(M[0, 1])
 
        # compute the new bounding dimensions of the image
        nW = int((h * sin) + (w * cos))
        nH = int((h * cos) + (w * sin))
 
        # adjust the rotation matrix to take into account translation
        M[0, 2] += (nW / 2) - cX
        M[1, 2] += (nH / 2) - cY
 
        # perform the actual rotation and return the image
        return cv2.warpAffine(image, M, (nW, nH))

    @staticmethod
    def set_video_source(source): #Declare picam to be desired camera source. 
        Camera.video_source = source

    @staticmethod
    def frames(): #function used by app.py to retrieve image
        with picamera.PiCamera() as camera:
            
            #Setting resolution (portrait) and framerate.
            camera.resolution = (1280, 720)
            camera.framerate = 60
            #camera.rotation = 90
                       
            rawCapture = PiRGBArray(camera, size=(1280,720))
            #Let camera warm up
            time.sleep(2)
            
            for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
                # grab the raw NumPy array representing the image, then initialize the timestamp
                # and occupied/unoccupied text
                
                #declare picam brightness, contrast and saturation attributes for next image
                                
                fb = open("bright.txt", "r")
                b = int(fb.read())
                fb.close()
                camera.brightness = b
            
                fc = open("contrast.txt", "r")           
                c = int(fc.read())
                fc.close()
                camera.contrast = c
            
                fs = open("saturation.txt", "r")           
                s = int(fs.read())
                fs.close()
                camera.saturation = s
                
                #save last frame array taken by camera as image
                image = frame.array
                cv2.imwrite("test_image.jpeg", image)
                
                #Rotating the image
                prerotate = cv2.imread('test_image.jpeg',0)
                angle = 90
            
                #https://www.pyimagesearch.com/2017/01/02/rotate-images-correctly-with-opencv-and-python/
                #Written by Adrian Rosebrock, January 2017
        
                # grab the dimensions of the image and then determine the
                # center
                (h, w) = prerotate.shape[:2]
                (cX, cY) = (w // 2, h // 2)
 
                # grab the rotation matrix (applying the negative of the
                # angle to rotate clockwise), then grab the sine and cosine
                # (i.e., the rotation components of the matrix)
                M = cv2.getRotationMatrix2D((cX, cY), -angle, 1.0)
                cos = np.abs(M[0, 0])
                sin = np.abs(M[0, 1])
 
                # compute the new bounding dimensions of the image
                nW = int((h * sin) + (w * cos))
                nH = int((h * cos) + (w * sin))
 
                # adjust the rotation matrix to take into account translation
                M[0, 2] += (nW / 2) - cX
                M[1, 2] += (nH / 2) - cY
 
                # perform the actual rotation and return the image
                rotated = cv2.warpAffine(image, M, (nW, nH))
                cv2.imwrite("test_image.jpeg", rotated)
                
                #Perform histogram equalization on saved image
                unhist = cv2.imread('test_image.jpeg',0)
                
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
                hist = clahe.apply(unhist)


                #return equalized image
                yield cv2.imencode('.jpg', hist)[1].tobytes()
                
                #clear last frame from camera stream
                rawCapture.seek(0)
                rawCapture.truncate()