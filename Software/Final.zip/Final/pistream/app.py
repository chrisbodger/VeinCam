#!/usr/bin/env python

#VEINCAM Main Application Script
#Authored by Alex Ollman for ENGN4221 Engineering Project
#Based on open source code from Miguel Grinberg (October 2014).
#https://blog.miguelgrinberg.com/post/video-streaming-with-flask
#Last Edited 8/10/2018

from flask import Flask, render_template, Response
import temp #to gain CPU temp of pi
from pijuice import PiJuice # PiJuice library to gain charging status and battery level of pijuice


from camera_opencv import Camera # Raspberry Pi camera module (requires picamera package)

app = Flask(__name__)



@app.route('/')
def index():
    
    #Read current brightness, saturation and contrast attribute values of PiCam
    b=open("bright.txt", "r")
    bright = int(b.read())
    b.close()

    s=open("saturation.txt", "r")
    saturation = int(s.read())
    s.close()

    c=open("contrast.txt", "r")
    contrast = int(c.read())
    c.close()
    
    pijuice = PiJuice(1, 0x14) # Instantiate PiJuice object

    batteryLvl = pijuice.status.GetChargeLevel().get('data') #Read current battery level
    charging = (pijuice.status.GetStatus().get('data')).get('powerInput') #Read current charge status    
    
    #Display on webpage charing status based on whether or not device is charging battery, simply on power or not conencted to power.
    if charging == "PRESENT" and int(batteryLvl) > 95:
        chr = "On Power"
    elif charging == "PRESENT":
        chr = "Charging"
    else:
        chr = "Not Charging"
    
    """Video streaming home page."""
    #Generate home page, parsing in above variables to be displayed on web page. 
    return render_template('index.html', bri = bright, sat = saturation, con = contrast, pi_temp = temp.measure_temp(), battery = batteryLvl, charge = chr)

def gen(camera):
    """Video streaming generator function."""
    #Recieve image from camera_opencv class (last image taken by camera), which will be test_image.jpg
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

#HTML Buttons
#Upon button press for Up or Down of an attribute, read current value from text files,
#check that values are within bounds, then add or subtract 10 from attribute.
#Save new value to affiliated text file, then refresh home page and camera stream.        
#More buttons can be added for finer tuning (+1 buttons)
        
@app.route('/brightnessUP/', methods=['POST'])
def brightnessUP():
    
    b=open("bright.txt", "r+")
    bright = int(b.read())
    b.seek(0)
    
    if bright < 100:
        bright += 10
    else:
        message = "Brightness at maximum"
        
    b.write("%d" % bright)
    b.truncate()
    b.close()
    
    return index()

@app.route('/contrastUP/', methods=['POST'])
def contrastUP():
    
    c=open("contrast.txt", "r+")
    contrast = int(c.read())
    c.seek(0)
    
    if contrast < 100:
        contrast += 10
    else:
        message = "Contrast at maximum"
        
    c.write("%d" % contrast)
    c.truncate()
    c.close()
    
    return index()

@app.route('/saturationUP/', methods=['POST'])
def saturationUP():
    
    s=open("saturation.txt", "r+")
    saturation = int(s.read())
    s.seek(0)
    
    if saturation < 100:
        saturation += 10
    else:
        message = "Saturation at maximum"
        
    s.write("%d" % saturation)
    s.truncate()
    s.close()
    
    return index() 
@app.route('/brightnessDOWN/', methods=['POST'])
def brightnessDOWN():
    
    b=open("bright.txt", "r+")
    bright = int(b.read())
    b.seek(0)
    
    if bright > 0:
        bright -= 10
    else:
        message = "Brightness at minimum"
    
    b.write("%d" % bright)
    b.truncate()
    b.close()
    
    return index()

@app.route('/contrastDOWN/', methods=['POST'])
def contrastDOWN():
    
    c=open("contrast.txt", "r+")
    contrast = int(c.read())
    c.seek(0)
        
    if contrast > -100:
        contrast -= 10
    else:
        message = "Contrast at minimum"
        
    c.write("%d" % contrast)
    c.truncate()
    c.close()
    
    return index()

@app.route('/saturationDOWN/', methods=['POST'])
def saturationDOWN():
    
    s=open("saturation.txt", "r+")
    saturation = int(s.read())
    s.seek(0)
    
    if saturation > -100:
        saturation -= 10
    else:
        message = "Saturation at minimum"
        
    s.write("%d" % saturation)
    s.truncate()
    s.close()
    
    return index()

# "Video"feed output to webpage, displaying latest image taken from camera each time it is refreshed (60 fps)
@app.route('/video_feed')
def video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(gen(Camera()),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

#Start the Flask server upon script run to IP address, port 8000.
if __name__ == '__main__':
    app.run(host='0.0.0.0', port='8000', debug=True, threaded=True)
    