from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
from base_camera import BaseCamera
 

class Camera(PiCamera):
    
    camera = PiCamera()
    camera.resolution = (640, 480)
    camera.framerate = 32
    #rawCapture = PiRGBArray(camera, size=(640,480))
    """An emulated camera implementation that streams a repeated sequence of
    files 1.jpg, 2.jpg and 3.jpg at a rate of one frame per second."""
    #imgs = [open(f + '.jpg', 'rb').read() for f in ['1', '2', '3']]
    camera.capture('test.jpg')
    unhist = cv2.imread('test.jpg',0)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    hist = clahe.apply(unhist)
    
    imgs = hist

    @staticmethod
    def frames():
        while True:
            time.sleep(0.5)
            yield Camera.imgs
