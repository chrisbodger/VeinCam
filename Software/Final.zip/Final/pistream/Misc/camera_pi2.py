import io
import cv2
import time
from picamera.array import PiRGBArray
import picamera
from base_camera import BaseCamera


class Camera(BaseCamera):
    @staticmethod
    def frames():
        with picamera.PiCamera() as camera:
            camera.resolution = (640, 480)
            camera.framerate = 32
            rawCapture = PiRGBArray(camera, size=(640,480))
            # let camera warm up
            time.sleep(2)
            
            for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
                # grab the raw NumPy array representing the image, then initialize the timestamp
                # and occupied/unoccupied text
                image = frame.array
                cv2.imwrite("test_image.jpeg", image)
                
                #Perform histogram equalization
                unhist = cv2.imread('test_image.jpeg',0)
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
                hist = clahe.apply(unhist)

                #image[10] = cl1
                
                yield hist
                
                rawCapture.seek(0)
                rawCapture.truncate()

            # show the frame
            #cv2.imshow("Frame", image)
            #cv2.imshow("Histogram", hist)
            #key = cv2.waitKey(1) & 0xFF
     
            # clear the stream in preparation for the next frame
            
            
            
     
            # if the `q` key was pressed, break from the loop
            #if key == ord("q"):
             #       break
           
