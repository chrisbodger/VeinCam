#!/bin/bash

cd /home/pi/pistream
python3 app.py
